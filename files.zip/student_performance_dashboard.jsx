import React, { useState } from 'react';
import { TrendingUp, AlertCircle, CheckCircle, Award } from 'lucide-react';

export default function StudentPerformanceDashboard() {
  const [studentData, setStudentData] = useState({
    student_id: '',
    attendance_rate: 85,
    previous_gpa: 3.0,
    study_hours_weekly: 20,
    assignment_completion: 80,
    participation_score: 70,
    sleep_hours: 7,
    extracurricular_activities: 1
  });

  const [prediction, setPrediction] = useState(null);
  const [loading, setLoading] = useState(false);

  // Mock model weights based on the ML system
  const featureWeights = {
    attendance_rate: 0.25,
    previous_gpa: 0.30,
    study_hours_weekly: 0.20,
    assignment_completion: 0.15,
    participation_score: 0.10,
    sleep_hours: 0.05,
    extracurricular_activities: -0.05
  };

  const predictPerformance = () => {
    setLoading(true);
    
    // Simulate API call to ML backend
    setTimeout(() => {
      const normalizedAttendance = studentData.attendance_rate / 100;
      const normalizedGPA = studentData.previous_gpa / 4;
      const normalizedStudyHours = Math.min(studentData.study_hours_weekly / 40, 1);
      const normalizedAssignment = studentData.assignment_completion / 100;
      const normalizedParticipation = studentData.participation_score / 100;
      const normalizedSleep = studentData.sleep_hours / 10;
      const normalizedExtracurricular = studentData.extracurricular_activities / 5;

      const predictedScore = (
        0.25 * normalizedAttendance +
        0.30 * normalizedGPA +
        0.20 * normalizedStudyHours +
        0.15 * normalizedAssignment +
        0.10 * normalizedParticipation +
        0.05 * normalizedSleep -
        0.05 * normalizedExtracurricular
      ) * 4 + (Math.random() * 0.3 - 0.15);

      const predictedGPA = Math.max(0, Math.min(4.0, predictedScore));
      
      const performanceLevel = 
        predictedGPA >= 3.7 ? 'Excellent' :
        predictedGPA >= 3.3 ? 'Very Good' :
        predictedGPA >= 2.7 ? 'Good' :
        predictedGPA >= 2.0 ? 'Fair' :
        'Needs Improvement';

      const recommendations = [];
      if (studentData.attendance_rate < 85) recommendations.push('Improve attendance - aim for >85%');
      if (studentData.study_hours_weekly < 15) recommendations.push('Increase study hours - consider 20+ hours/week');
      if (studentData.assignment_completion < 80) recommendations.push('Complete assignments on time - target 100%');
      if (studentData.sleep_hours < 7) recommendations.push('Get more sleep - aim for 7-8 hours/night');
      if (studentData.participation_score < 50) recommendations.push('Increase class participation and engagement');
      if (recommendations.length === 0) recommendations.push('Maintain current performance - you\'re doing great!');

      setPrediction({
        studentId: studentData.student_id || 'Sample Student',
        predictedGPA: predictedGPA.toFixed(2),
        performanceLevel,
        recommendations,
        confidence: (0.85 + Math.random() * 0.1).toFixed(2)
      });
      
      setLoading(false);
    }, 800);
  };

  const handleInputChange = (field, value) => {
    setStudentData(prev => ({
      ...prev,
      [field]: parseFloat(value) || value
    }));
  };

  const getPerformanceColor = (level) => {
    switch(level) {
      case 'Excellent': return 'var(--color-text-success)';
      case 'Very Good': return 'var(--color-text-success)';
      case 'Good': return 'var(--color-text-info)';
      case 'Fair': return 'var(--color-text-warning)';
      case 'Needs Improvement': return 'var(--color-text-danger)';
      default: return 'var(--color-text-secondary)';
    }
  };

  const getPerformanceBgColor = (level) => {
    switch(level) {
      case 'Excellent': return 'var(--color-background-success)';
      case 'Very Good': return 'var(--color-background-success)';
      case 'Good': return 'var(--color-background-info)';
      case 'Fair': return 'var(--color-background-warning)';
      case 'Needs Improvement': return 'var(--color-background-danger)';
      default: return 'var(--color-background-tertiary)';
    }
  };

  return (
    <div style={{ padding: '1rem 0' }}>
      <div style={{ marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '22px', fontWeight: 500, marginBottom: '0.5rem' }}>Student Performance Predictor</h2>
        <p style={{ color: 'var(--color-text-secondary)', marginBottom: '1.5rem' }}>
          Enter student metrics to predict academic performance using AI
        </p>

        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '1rem',
          marginBottom: '1.5rem'
        }}>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '14px', fontWeight: 500, marginBottom: '0.5rem' }}>Student ID</label>
            <input
              type="text"
              value={studentData.student_id}
              onChange={(e) => handleInputChange('student_id', e.target.value)}
              placeholder="Enter student ID"
              style={{
                padding: '0.75rem',
                border: '1px solid var(--color-border-tertiary)',
                borderRadius: 'var(--border-radius-md)',
                fontSize: '14px',
                fontFamily: 'var(--font-sans)'
              }}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '14px', fontWeight: 500, marginBottom: '0.5rem' }}>Attendance Rate (%)</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input
                type="range"
                min="0"
                max="100"
                value={studentData.attendance_rate}
                onChange={(e) => handleInputChange('attendance_rate', e.target.value)}
                style={{ flex: 1 }}
              />
              <span style={{ minWidth: '40px', textAlign: 'right', fontSize: '14px', fontWeight: 500 }}>
                {studentData.attendance_rate}%
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '14px', fontWeight: 500, marginBottom: '0.5rem' }}>Previous GPA</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input
                type="range"
                min="0"
                max="4"
                step="0.1"
                value={studentData.previous_gpa}
                onChange={(e) => handleInputChange('previous_gpa', e.target.value)}
                style={{ flex: 1 }}
              />
              <span style={{ minWidth: '40px', textAlign: 'right', fontSize: '14px', fontWeight: 500 }}>
                {studentData.previous_gpa.toFixed(1)}
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '14px', fontWeight: 500, marginBottom: '0.5rem' }}>Study Hours/Week</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input
                type="range"
                min="0"
                max="50"
                value={studentData.study_hours_weekly}
                onChange={(e) => handleInputChange('study_hours_weekly', e.target.value)}
                style={{ flex: 1 }}
              />
              <span style={{ minWidth: '40px', textAlign: 'right', fontSize: '14px', fontWeight: 500 }}>
                {studentData.study_hours_weekly}h
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '14px', fontWeight: 500, marginBottom: '0.5rem' }}>Assignment Completion (%)</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input
                type="range"
                min="0"
                max="100"
                value={studentData.assignment_completion}
                onChange={(e) => handleInputChange('assignment_completion', e.target.value)}
                style={{ flex: 1 }}
              />
              <span style={{ minWidth: '40px', textAlign: 'right', fontSize: '14px', fontWeight: 500 }}>
                {studentData.assignment_completion}%
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '14px', fontWeight: 500, marginBottom: '0.5rem' }}>Participation Score</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input
                type="range"
                min="0"
                max="100"
                value={studentData.participation_score}
                onChange={(e) => handleInputChange('participation_score', e.target.value)}
                style={{ flex: 1 }}
              />
              <span style={{ minWidth: '40px', textAlign: 'right', fontSize: '14px', fontWeight: 500 }}>
                {studentData.participation_score}
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '14px', fontWeight: 500, marginBottom: '0.5rem' }}>Sleep Hours/Night</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input
                type="range"
                min="0"
                max="12"
                step="0.5"
                value={studentData.sleep_hours}
                onChange={(e) => handleInputChange('sleep_hours', e.target.value)}
                style={{ flex: 1 }}
              />
              <span style={{ minWidth: '40px', textAlign: 'right', fontSize: '14px', fontWeight: 500 }}>
                {studentData.sleep_hours}h
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '14px', fontWeight: 500, marginBottom: '0.5rem' }}>Extracurricular Activities</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input
                type="range"
                min="0"
                max="5"
                value={studentData.extracurricular_activities}
                onChange={(e) => handleInputChange('extracurricular_activities', e.target.value)}
                style={{ flex: 1 }}
              />
              <span style={{ minWidth: '40px', textAlign: 'right', fontSize: '14px', fontWeight: 500 }}>
                {studentData.extracurricular_activities}
              </span>
            </div>
          </div>
        </div>

        <button
          onClick={predictPerformance}
          disabled={loading}
          style={{
            padding: '0.75rem 2rem',
            backgroundColor: 'var(--color-text-info)',
            color: 'white',
            border: 'none',
            borderRadius: 'var(--border-radius-md)',
            fontSize: '16px',
            fontWeight: 500,
            cursor: loading ? 'not-allowed' : 'pointer',
            opacity: loading ? 0.7 : 1,
            transition: 'opacity 0.2s'
          }}
        >
          {loading ? 'Predicting...' : 'Predict Performance'}
        </button>
      </div>

      {prediction && (
        <div style={{
          backgroundColor: 'var(--color-background-secondary)',
          border: '1px solid var(--color-border-tertiary)',
          borderRadius: 'var(--border-radius-lg)',
          padding: '1.5rem'
        }}>
          <h3 style={{ fontSize: '18px', fontWeight: 500, marginBottom: '1rem' }}>Prediction Results</h3>

          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '1rem',
            marginBottom: '1.5rem'
          }}>
            <div style={{
              backgroundColor: 'var(--color-background-primary)',
              border: '1px solid var(--color-border-tertiary)',
              borderRadius: 'var(--border-radius-md)',
              padding: '1rem'
            }}>
              <div style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>
                Student ID
              </div>
              <div style={{ fontSize: '18px', fontWeight: 500 }}>
                {prediction.studentId}
              </div>
            </div>

            <div style={{
              backgroundColor: 'var(--color-background-primary)',
              border: '1px solid var(--color-border-tertiary)',
              borderRadius: 'var(--border-radius-md)',
              padding: '1rem'
            }}>
              <div style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>
                Predicted GPA
              </div>
              <div style={{ fontSize: '24px', fontWeight: 500 }}>
                {prediction.predictedGPA}
              </div>
            </div>

            <div style={{
              backgroundColor: getPerformanceBgColor(prediction.performanceLevel),
              border: '1px solid var(--color-border-tertiary)',
              borderRadius: 'var(--border-radius-md)',
              padding: '1rem'
            }}>
              <div style={{ fontSize: '14px', color: getPerformanceColor(prediction.performanceLevel), marginBottom: '0.5rem' }}>
                Performance Level
              </div>
              <div style={{ fontSize: '18px', fontWeight: 500, color: getPerformanceColor(prediction.performanceLevel) }}>
                {prediction.performanceLevel}
              </div>
            </div>

            <div style={{
              backgroundColor: 'var(--color-background-primary)',
              border: '1px solid var(--color-border-tertiary)',
              borderRadius: 'var(--border-radius-md)',
              padding: '1rem'
            }}>
              <div style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>
                Prediction Confidence
              </div>
              <div style={{ fontSize: '18px', fontWeight: 500 }}>
                {(prediction.confidence * 100).toFixed(0)}%
              </div>
            </div>
          </div>

          <div style={{ marginTop: '1.5rem' }}>
            <h4 style={{ fontSize: '16px', fontWeight: 500, marginBottom: '1rem' }}>Recommendations</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {prediction.recommendations.map((rec, idx) => (
                <div
                  key={idx}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    padding: '0.75rem',
                    backgroundColor: 'var(--color-background-primary)',
                    borderRadius: 'var(--border-radius-md)',
                    border: '1px solid var(--color-border-tertiary)'
                  }}
                >
                  <AlertCircle size={20} style={{ color: 'var(--color-text-info)', flexShrink: 0 }} />
                  <span style={{ fontSize: '14px' }}>{rec}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
