"""
QUICK START GUIDE - Student Performance Prediction System
"""

# ============================================================
# INSTALLATION
# ============================================================

# 1. Create a virtual environment (optional but recommended)
"""
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
"""

# 2. Install required packages
"""
pip install -r requirements.txt
"""

# Or install manually:
"""
pip install numpy==1.24.3
pip install pandas==2.0.3
pip install scikit-learn==1.3.0
pip install joblib==1.3.1
pip install flask==2.3.2
pip install flask-cors==4.0.0
"""


# ============================================================
# QUICK START - 5 MINUTES
# ============================================================

"""
Step 1: Train the Model (2 minutes)
-----------------------------------
"""

from student_performance_system import (
    StudentDataGenerator,
    PerformancePredictor
)

print("Training model...")
generator = StudentDataGenerator()
df = generator.generate_dataset(n_students=500)

predictor = PerformancePredictor()
metrics = predictor.train(df, model_type='gradient_boosting')

print(f"✓ Model trained! R² Score: {metrics['r2_score']:.4f}")


"""
Step 2: Make a Prediction (1 minute)
------------------------------------
"""

from student_performance_system import StudentAnalyzer

analyzer = StudentAnalyzer(predictor)

# Example student data
student = {
    'student_id': 'DEMO001',
    'attendance_rate': 85,
    'previous_gpa': 3.2,
    'study_hours_weekly': 20,
    'assignment_completion': 85,
    'participation_score': 75,
    'sleep_hours': 7,
    'extracurricular_activities': 1
}

analysis = analyzer.predict_and_analyze(student)

print("\n📊 PREDICTION RESULTS")
print(f"Student ID: {analysis['student_id']}")
print(f"Predicted GPA: {analysis['predicted_gpa']}")
print(f"Performance Level: {analysis['performance_level']}")
print("\n💡 Recommendations:")
for i, rec in enumerate(analysis['recommendations'], 1):
    print(f"   {i}. {rec}")


"""
Step 3: Start API Server (2 minutes)
------------------------------------
"""

# In terminal:
"""
python api_server.py
"""

# Output:
"""
============================================================
Student Performance Prediction API Server
============================================================

API Documentation available at: http://localhost:5000/api/docs

Starting server on http://localhost:5000
============================================================
"""


"""
Step 4: Test API Endpoints (using curl or Python)
--------------------------------------------------
"""

import requests

# Test single prediction
response = requests.post(
    'http://localhost:5000/api/predict',
    json={
        'student_id': '1001',
        'attendance_rate': 90,
        'previous_gpa': 3.5,
        'study_hours_weekly': 25,
        'assignment_completion': 95,
        'participation_score': 85,
        'sleep_hours': 8,
        'extracurricular_activities': 2
    }
)

result = response.json()
print(f"✓ API Response: {result['prediction']['predicted_gpa']}")


"""
Step 5: Use the Dashboard
------------------------
"""

# The React dashboard component is in:
# student_performance_dashboard.jsx
# 
# Import it into your React app:
# import StudentPerformanceDashboard from './student_performance_dashboard'
# 
# Use it:
# <StudentPerformanceDashboard />


# ============================================================
# COMMON TASKS
# ============================================================

def task_1_train_with_custom_data():
    """Train model with custom CSV data"""
    import pandas as pd
    from student_performance_system import PerformancePredictor
    
    # Load your data
    df = pd.read_csv('student_data.csv')
    
    # Train
    predictor = PerformancePredictor()
    metrics = predictor.train(df)
    
    print(f"Model trained! Metrics: {metrics}")


def task_2_batch_predictions():
    """Make predictions for multiple students"""
    import requests
    
    students = [
        {
            'student_id': '1001',
            'attendance_rate': 90,
            'previous_gpa': 3.5,
            'study_hours_weekly': 25,
            'assignment_completion': 95,
            'participation_score': 85,
            'sleep_hours': 8,
            'extracurricular_activities': 2
        },
        # Add more students...
    ]
    
    response = requests.post(
        'http://localhost:5000/api/batch-predict',
        json={'students': students}
    )
    
    predictions = response.json()
    return predictions['predictions']


def task_3_generate_report():
    """Generate comprehensive report"""
    from student_performance_system import PerformanceReportGenerator
    
    report = PerformanceReportGenerator.generate_report(
        predictions=[],
        model_metrics={}
    )
    
    # Save to file
    import json
    with open('report.json', 'w') as f:
        json.dump(report, f, indent=2)


def task_4_save_load_model():
    """Save trained model for later use"""
    
    # Save
    predictor.save_model('my_model.pkl')
    
    # Later, load
    from student_performance_system import PerformancePredictor
    new_predictor = PerformancePredictor()
    new_predictor.load_model('my_model.pkl')


def task_5_feature_importance():
    """Understand what factors matter most"""
    
    importance = predictor.get_feature_importance()
    
    for feature, score in sorted(importance.items(), key=lambda x: x[1], reverse=True):
        print(f"{feature}: {score:.1f}%")


# ============================================================
# API CHEAT SHEET
# ============================================================

API_CHEAT_SHEET = """
╔════════════════════════════════════════════════════════════╗
║         API QUICK REFERENCE                               ║
╠════════════════════════════════════════════════════════════╣
║                                                            ║
║ 1. HEALTH CHECK                                           ║
║    GET /api/health                                        ║
║    Response: {"status": "healthy"}                        ║
║                                                            ║
║ 2. TRAIN MODEL                                            ║
║    POST /api/train                                        ║
║    Body: {"n_students": 500, "model_type": "..."}        ║
║    Response: {"message": "....", "metrics": {...}}        ║
║                                                            ║
║ 3. MAKE PREDICTION                                        ║
║    POST /api/predict                                      ║
║    Body: {student_data}                                   ║
║    Response: {"prediction": {...}}                        ║
║                                                            ║
║ 4. BATCH PREDICTIONS                                      ║
║    POST /api/batch-predict                                ║
║    Body: {"students": [...]}                              ║
║    Response: {"total_predictions": N, "predictions": [...]}
║                                                            ║
║ 5. FEATURE IMPORTANCE                                     ║
║    GET /api/feature-importance                            ║
║    Response: {"feature_importance": {...}}                ║
║                                                            ║
║ 6. MODEL INFO                                             ║
║    GET /api/model-info                                    ║
║    Response: {"model_type": "...", "metrics": {...}}      ║
║                                                            ║
║ 7. GENERATE REPORT                                        ║
║    POST /api/generate-report                              ║
║    Body: {"students": [...]}                              ║
║    Response: {report}                                     ║
║                                                            ║
║ 8. API DOCUMENTATION                                      ║
║    GET /api/docs                                          ║
║    Response: Complete API documentation                   ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
"""


# ============================================================
# TROUBLESHOOTING
# ============================================================

TROUBLESHOOTING = {
    'import_error': {
        'problem': 'ModuleNotFoundError: No module named ...',
        'solution': 'pip install -r requirements.txt'
    },
    
    'model_not_trained': {
        'problem': 'ValueError: Model not trained yet',
        'solution': 'Call predictor.train() before predict()'
    },
    
    'missing_fields': {
        'problem': 'Missing required fields in request',
        'solution': 'All 7 fields required: attendance_rate, previous_gpa, study_hours_weekly, assignment_completion, participation_score, sleep_hours, extracurricular_activities'
    },
    
    'port_already_in_use': {
        'problem': 'Address already in use on port 5000',
        'solution': 'Change port in api_server.py or kill existing process'
    },
    
    'prediction_out_of_range': {
        'problem': 'Prediction is 4.5 (should be 0-4.0)',
        'solution': 'This is handled automatically - predictions are clipped to 0-4.0'
    },
}


# ============================================================
# PERFORMANCE TIPS
# ============================================================

PERFORMANCE_TIPS = """
1. BATCH PROCESSING
   - Process 100+ predictions at once with /api/batch-predict
   - More efficient than individual predictions

2. MODEL CACHING
   - Save trained model with model.save_model()
   - Reuse with model.load_model() instead of retraining

3. ASYNC PROCESSING
   - Use async/await for API calls in web apps
   - Prevents blocking on long operations

4. MONITORING
   - Check /api/status for model information
   - Monitor API response times
   - Log prediction results

5. SCALING
   - Consider using a production WSGI server (Gunicorn)
   - Deploy as Docker container
   - Use cloud platform auto-scaling
"""


# ============================================================
# EXAMPLE DATA FORMATS
# ============================================================

STUDENT_DATA_TEMPLATE = {
    'student_id': 'S001',           # String ID
    'attendance_rate': 85,           # 0-100 percent
    'previous_gpa': 3.2,             # 0.0-4.0
    'study_hours_weekly': 20,        # 0-50+ hours
    'assignment_completion': 85,     # 0-100 percent
    'participation_score': 75,       # 0-100 score
    'sleep_hours': 7,                # 0-12 hours
    'extracurricular_activities': 1  # 0-5+ count
}

BATCH_REQUEST_TEMPLATE = {
    'students': [
        STUDENT_DATA_TEMPLATE,
        # ... more students
    ]
}

TRAIN_REQUEST_TEMPLATE = {
    'n_students': 500,
    'model_type': 'gradient_boosting'  # or 'random_forest', 'linear_regression'
}


# ============================================================
# RUN ALL TESTS
# ============================================================

"""
To verify everything works:

python test_suite.py

This will:
- Run 30+ unit tests
- Run integration tests
- Show example usage
- Verify all components
"""


# ============================================================
# WHAT'S INCLUDED
# ============================================================

PACKAGE_CONTENTS = {
    'Core System': [
        'student_performance_system.py (1000+ lines)',
        'Complete ML implementation',
        'Data generation and analysis',
    ],
    
    'API Server': [
        'api_server.py (600+ lines)',
        'Flask REST API',
        'Multiple endpoints',
    ],
    
    'Frontend': [
        'student_performance_dashboard.jsx',
        'React component',
        'Interactive UI',
    ],
    
    'Testing': [
        'test_suite.py (600+ lines)',
        '30+ test cases',
        'Example usage',
    ],
    
    'Documentation': [
        'README.md (Complete guide)',
        'SYSTEM_OVERVIEW.md (Architecture)',
        'This quick start guide',
    ],
    
    'Configuration': [
        'config_and_examples.py',
        'API examples',
        'Usage patterns',
    ]
}


# ============================================================
# GETTING HELP
# ============================================================

GETTING_HELP = """
1. READ THE DOCS
   - README.md: Complete documentation
   - SYSTEM_OVERVIEW.md: Architecture and design
   - This file: Quick start

2. CHECK EXAMPLES
   - See config_and_examples.py for examples
   - Check test_suite.py for usage patterns
   - Review API_EXAMPLES in config_and_examples.py

3. API DOCUMENTATION
   - Visit http://localhost:5000/api/docs
   - Lists all endpoints with examples
   - Shows request/response formats

4. RUN TESTS
   - python test_suite.py
   - Shows what's working
   - Provides example usage

5. CHECK SOURCE CODE
   - Well-commented code
   - Docstrings for all classes/methods
   - Clear variable names
"""


if __name__ == '__main__':
    print("="*60)
    print("STUDENT PERFORMANCE PREDICTION SYSTEM - QUICK START")
    print("="*60)
    
    print("\n📦 INSTALLATION")
    print("-" * 60)
    print("1. pip install -r requirements.txt")
    print("2. python student_performance_system.py")
    print("3. python api_server.py")
    
    print("\n📊 USAGE")
    print("-" * 60)
    print("See example code above for:")
    print("- Training models")
    print("- Making predictions")
    print("- Using the API")
    print("- Common tasks")
    
    print("\n✅ VERIFY INSTALLATION")
    print("-" * 60)
    print("Run: python test_suite.py")
    
    print("\n📖 DOCUMENTATION")
    print("-" * 60)
    print("- README.md: Complete guide")
    print("- SYSTEM_OVERVIEW.md: Architecture")
    print("- config_and_examples.py: Examples")
    
    print("\n🚀 NEXT STEPS")
    print("-" * 60)
    print("1. Install requirements: pip install -r requirements.txt")
    print("2. Run tests: python test_suite.py")
    print("3. Start API: python api_server.py")
    print("4. Check API docs: http://localhost:5000/api/docs")
    
    print("\n" + "="*60)
    print("Ready to go! 🎉")
    print("="*60)
