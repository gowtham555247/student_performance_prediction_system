# AI Student Performance Prediction System

A comprehensive machine learning system for predicting student academic performance based on behavioral and academic metrics. This system uses advanced algorithms to analyze student data and provide personalized recommendations for academic improvement.

## Features

- **Multiple ML Models**: Gradient Boosting, Random Forest, and Linear Regression
- **Performance Prediction**: Predict final GPA based on current metrics
- **Personalized Recommendations**: Generate tailored advice for improvement
- **Feature Importance Analysis**: Understand which factors matter most
- **Batch Processing**: Handle multiple student predictions at once
- **API Server**: REST API for easy integration
- **Interactive Dashboard**: React-based web UI for predictions
- **Model Persistence**: Save and load trained models
- **Comprehensive Analytics**: Detailed reports and insights

## System Architecture

```
┌─────────────────────────────────────────────────────┐
│         Student Performance Prediction System       │
├─────────────────────────────────────────────────────┤
│                                                     │
│  ┌─────────────────┐     ┌──────────────────┐    │
│  │   Data Layer    │     │   Model Layer    │    │
│  │                 │     │                  │    │
│  │  - Generator    │────▶│  - ML Models     │    │
│  │  - Preprocessing│     │  - Training      │    │
│  │  - Validation   │     │  - Evaluation    │    │
│  └─────────────────┘     └──────────────────┘    │
│                                                     │
│  ┌─────────────────┐     ┌──────────────────┐    │
│  │   API Layer     │     │  Presentation    │    │
│  │                 │     │                  │    │
│  │  - REST API     │     │  - Dashboard     │    │
│  │  - Endpoints    │────▶│  - Web UI        │    │
│  │  - Error Handle │     │  - Visualization │    │
│  └─────────────────┘     └──────────────────┘    │
│                                                     │
└─────────────────────────────────────────────────────┘
```

## Installation

### Requirements

- Python 3.8+
- pip package manager

### Dependencies

```bash
pip install numpy pandas scikit-learn joblib flask flask-cors
```

### Quick Start

1. **Install dependencies**:
   ```bash
   pip install numpy pandas scikit-learn joblib flask flask-cors
   ```

2. **Run the system**:
   ```bash
   python student_performance_system.py
   ```

3. **Start the API server**:
   ```bash
   python api_server.py
   ```

4. **Access the dashboard**:
   - Open the React component in your web application
   - Or use the API endpoints directly

## Usage

### 1. Training a Model

#### Python Script
```python
from student_performance_system import (
    StudentDataGenerator,
    PerformancePredictor
)

# Generate data
generator = StudentDataGenerator()
df = generator.generate_dataset(n_students=500)

# Train model
predictor = PerformancePredictor()
metrics = predictor.train(df, model_type='gradient_boosting')

print(f"R² Score: {metrics['r2_score']:.4f}")
print(f"RMSE: {metrics['rmse']:.4f}")
```

#### API Request
```bash
curl -X POST http://localhost:5000/api/train \
  -H "Content-Type: application/json" \
  -d '{
    "n_students": 500,
    "model_type": "gradient_boosting"
  }'
```

### 2. Making Predictions

#### Single Prediction
```python
from student_performance_system import StudentAnalyzer

student_data = {
    'student_id': 1001,
    'attendance_rate': 90,
    'previous_gpa': 3.5,
    'study_hours_weekly': 25,
    'assignment_completion': 95,
    'participation_score': 85,
    'sleep_hours': 8,
    'extracurricular_activities': 2
}

analyzer = StudentAnalyzer(predictor)
analysis = analyzer.predict_and_analyze(student_data)

print(f"Predicted GPA: {analysis['predicted_gpa']}")
print(f"Performance Level: {analysis['performance_level']}")
```

#### API Request
```bash
curl -X POST http://localhost:5000/api/predict \
  -H "Content-Type: application/json" \
  -d '{
    "student_id": "1001",
    "attendance_rate": 90,
    "previous_gpa": 3.5,
    "study_hours_weekly": 25,
    "assignment_completion": 95,
    "participation_score": 85,
    "sleep_hours": 8,
    "extracurricular_activities": 2
  }'
```

### 3. Batch Predictions

```bash
curl -X POST http://localhost:5000/api/batch-predict \
  -H "Content-Type: application/json" \
  -d '{
    "students": [
      {
        "student_id": "1001",
        "attendance_rate": 90,
        "previous_gpa": 3.5,
        ...
      },
      {
        "student_id": "1002",
        "attendance_rate": 75,
        "previous_gpa": 2.8,
        ...
      }
    ]
  }'
```

### 4. Feature Importance

```bash
curl -X GET http://localhost:5000/api/feature-importance
```

**Response:**
```json
{
  "feature_importance": {
    "previous_gpa": 30.2,
    "attendance_rate": 25.1,
    "study_hours_weekly": 20.3,
    "assignment_completion": 15.2,
    "participation_score": 10.1,
    "sleep_hours": 5.0,
    "extracurricular_activities": -4.9
  }
}
```

## Input Features

| Feature | Type | Range | Description |
|---------|------|-------|-------------|
| attendance_rate | Float | 0-100 | Percentage of classes attended |
| previous_gpa | Float | 0-4.0 | Previous semester GPA |
| study_hours_weekly | Float | 0-50+ | Hours spent studying per week |
| assignment_completion | Float | 0-100 | Percentage of assignments completed |
| participation_score | Float | 0-100 | Class participation score |
| sleep_hours | Float | 0-12 | Average sleep hours per night |
| extracurricular_activities | Int | 0-5+ | Number of activities |

## Output

### Prediction Result

```json
{
  "student_id": "1001",
  "predicted_gpa": 3.65,
  "performance_level": "Excellent",
  "recommendations": [
    "Maintain current performance - you're doing great!",
    "Consider taking more advanced courses"
  ],
  "confidence": 0.92
}
```

## Performance Levels

| Level | GPA Range | Color |
|-------|-----------|-------|
| Excellent | 3.7-4.0 | Green |
| Very Good | 3.3-3.7 | Green |
| Good | 2.7-3.3 | Blue |
| Fair | 2.0-2.7 | Yellow |
| Needs Improvement | 0-2.0 | Red |

## API Endpoints

### Health & Status
- `GET /api/health` - Health check
- `GET /api/status` - Model status

### Training
- `POST /api/train` - Train new model
- `POST /api/save-model` - Save model
- `POST /api/load-model` - Load model

### Predictions
- `POST /api/predict` - Single prediction
- `POST /api/batch-predict` - Batch predictions

### Analytics
- `GET /api/feature-importance` - Feature importance
- `GET /api/model-info` - Model information
- `POST /api/generate-report` - Generate report

### Recommendations
- `POST /api/get-recommendations` - Get recommendations

## Model Performance

### Metrics

The system evaluates models using:
- **R² Score**: Coefficient of determination (0-1, higher is better)
- **RMSE**: Root Mean Square Error (lower is better)
- **MAE**: Mean Absolute Error (lower is better)

### Example Metrics

```
Model: Gradient Boosting
R² Score: 0.8234
RMSE: 0.3421
MAE: 0.2341
Training Time: 2.34 seconds
```

## Feature Importance

The system calculates which factors have the most impact on performance:

1. **Previous GPA** (30%) - Historical academic performance
2. **Attendance** (25%) - Class attendance rate
3. **Study Hours** (20%) - Weekly study commitment
4. **Assignments** (15%) - Assignment completion rate
5. **Participation** (10%) - Class participation
6. **Sleep** (5%) - Sleep hours per night
7. **Extracurricular** (-5%) - Can be a distraction if excessive

## Recommendations Engine

The system generates personalized recommendations:

- **Low Attendance**: "Improve attendance - aim for >85%"
- **Low Study Time**: "Increase study hours - consider 20+ hours/week"
- **Low Assignment Completion**: "Complete assignments on time - target 100%"
- **Inadequate Sleep**: "Get more sleep - aim for 7-8 hours/night"
- **Low Participation**: "Increase class participation and engagement"
- **Excellent Performance**: "Maintain current performance - you're doing great!"

## Advanced Usage

### Saving and Loading Models

```python
# Save model
predictor.save_model('my_model.pkl')

# Load model
predictor.load_model('my_model.pkl')
```

### Getting Feature Importance

```python
importance = predictor.get_feature_importance()
for feature, score in sorted(importance.items(), key=lambda x: x[1], reverse=True):
    print(f"{feature}: {score:.1f}%")
```

### Generating Reports

```python
from student_performance_system import PerformanceReportGenerator

report_gen = PerformanceReportGenerator()
report = report_gen.generate_report(predictions, model_metrics)

# Save to file
import json
with open('report.json', 'w') as f:
    json.dump(report, f, indent=2)
```

## Customization

### Adding New Features

1. Update `StudentDataGenerator.generate_dataset()` to include new features
2. Add feature to `PerformancePredictor.feature_names`
3. Update the formula in `StudentDataGenerator` to incorporate the feature
4. Retrain the model

### Changing Model Type

```python
# Use Random Forest
predictor.train(df, model_type='random_forest')

# Use Linear Regression
predictor.train(df, model_type='linear_regression')
```

## Troubleshooting

### Model Not Trained
**Error**: "Model not trained yet"
**Solution**: Call `POST /api/train` before making predictions

### Missing Fields
**Error**: "Missing fields: attendance_rate, ..."
**Solution**: Ensure all 7 required fields are provided in the request

### File Not Found
**Error**: "Model file not found"
**Solution**: Check the filepath and ensure the model has been saved

## Deployment

### Docker

Create a `Dockerfile`:
```dockerfile
FROM python:3.9
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "api_server.py"]
```

Build and run:
```bash
docker build -t student-predictor .
docker run -p 5000:5000 student-predictor
```

### Cloud Deployment

The API can be deployed to:
- AWS Lambda (with serverless framework)
- Google Cloud Run
- Azure App Service
- Heroku
- DigitalOcean

## Performance Tips

1. **Batch Processing**: Use batch predictions for better efficiency
2. **Model Caching**: Cache the trained model to avoid retraining
3. **Feature Scaling**: Data is automatically scaled during preprocessing
4. **Async Processing**: Consider async API calls for large batches

## Security

- Validate all input data
- Use HTTPS in production
- Implement authentication for API endpoints
- Sanitize student identifiers
- Log all predictions for audit trails

## Future Enhancements

- [ ] Time-series forecasting for semester progression
- [ ] Clustering analysis to identify at-risk students
- [ ] Integration with student information systems (SIS)
- [ ] Real-time alerts for declining performance
- [ ] Mobile app support
- [ ] Multi-class classification (A, B, C, D, F grades)
- [ ] Early warning system implementation
- [ ] Explainability features (SHAP values)

## Citation

If you use this system in research, please cite:

```
Student Performance Prediction System
ML-Based Academic Analytics Platform
Version 1.0.0
```

## License

MIT License - See LICENSE file for details

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review API documentation at `/api/docs`
3. Check example files
4. Review the source code comments

## Version History

### v1.0.0 (Current)
- Initial release
- Gradient Boosting, Random Forest, Linear Regression models
- REST API server
- React dashboard
- Batch prediction support
- Feature importance analysis

## Authors

AI Research Team

## Acknowledgments

Built with scikit-learn, Flask, and React.js
